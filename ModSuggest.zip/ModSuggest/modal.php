<div class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
   <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <h2 class="modal-title text-center">Login</h2>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
         </div>
         <div class="modal-body">
            <div class="row">
               <div class="col-md-12">
                  <label>Email</label>
                  <div class="form-group mb-3">
                     <input type="text" placeholder="@gmail.com" value="" class="form-control">
                  </div>
               </div>
               <div class="col-md-12">
                  <label>Password</label>
                  <div class="form-group mb-3">
                     <input type="text" placeholder="12345678" value="" class="form-control">
                  </div>
               </div>
               <div class="col-md-6 d-flex align-items-center">
                  <div class="custom-check">
                     <input class="" type="checkbox" value="" id="flexCheckDefault">
                     <label class="" for="flexCheckDefault">
                     Remember Me
                     </label>
                  </div>
               </div>
               <div class="col-md-6 text-end">
                  <a data-bs-target="#exampleModalToggle2" data-bs-toggle="modal" data-bs-dismiss="modal" href="javascript:void(0)">Forget password?</a>
               </div>
               <div class="col-md-12 mt-5">
                   <a class="btn btn-primary" href="#">Login</a>
                  
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>

<div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2" tabindex="-1">
   <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <h2 class="modal-title text-center">Forget Password</h2>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="far fa-times-circle"></i></button>
         </div>
         <div class="modal-body">
            <div class="row">
               <div class="col-md-12">
                  <label>Email</label>
                  <div class="form-group mb-3">
                     <input type="text" placeholder="@gmail.com" value="" class="form-control">
                  </div>
               </div>
               <div class="col-md-12 mt-5">
                   <a href="#" class="btn btn-primary">Reset</a>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>










