<?php include("header.php"); ?>

<main id="main">
    <section class="home-banner">
        <div class="container">
            <h1>Welcome to ModSuggest</h1>
            <h2>Where You Go For More Horsepower</h2>
            <div class="banner-search">
                <input type="text" placeholder="Enter vehicle year, make and model">
                <button class="btn btn-primary"><i class="las la-search"></i> Search</button>
            </div>
        </div>
    </section>

    <section class="ptb-90 services">
        <div class="container">
            <h2 class="mb-4 pb-2">Our Services</h2>
            <p class="col-md-9">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic
                typesetting, remaining essentially unchanged.</p>




            <div id="recipeCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner" role="listbox">
                    <div class="carousel-item active">
                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-img">
                                    <img src="images/icon1.png" class="img-fluid">
                                </div>
                                <div class="card-img-overlay">
                                    <h3>Find Shop</h3>
                                    <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-img">
                                    <img src="images/icon2.png" class="img-fluid">
                                </div>
                                <div class="card-img-overlay">
                                    <h3>Find Local Tech</h3>
                                    <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-img">
                                    <img src="images/icon3.png" class="img-fluid">
                                </div>
                                <div class="card-img-overlay">
                                    <h3>Find Parts</h3>
                                    <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-img">
                                    <img src="images/icon4.png" class="img-fluid">
                                </div>
                                <div class="card-img-overlay">
                                    <h3>Find Tuners</h3>
                                    <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-img">
                                    <img src="images/icon1.png" class="img-fluid">
                                </div>
                                <div class="card-img-overlay">
                                    <h3>Find Shop</h3>
                                    <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="col-md-3">
                            <div class="card">
                                <div class="card-img">
                                    <img src="images/icon2.png" class="img-fluid">
                                </div>
                                <div class="card-img-overlay">
                                    <h3>Find Local Tech</h3>
                                    <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="controls">
                    <a class="carousel-control-prev" href="#recipeCarousel" role="button" data-bs-slide="prev">
                        <i class="fas fa-chevron-left"></i>
                    </a>
                    <a class="carousel-control-next" href="#recipeCarousel" role="button" data-bs-slide="next">
                        <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <section class="about pb-90">
        <div class="container-fluid px-0">
            <div class="row gx-0">
                <div class="col-md-6">
                    <div class="abt-img"><img src="images/about.png" alt="" class="w-100" /></div>
                </div>
                <div class="col-md-6 abt-con d-flex flex-wrap align-self-center">

                    <h2 class="mb-4 pb-2">About Us</h2>
                    <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into
                        electronic typesetting, remaining essentially unchanged. It popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishin software like Aldus PageMaker including
                        versions of Lorem Ipsum.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a t specimen book. It has survived not only five centuries,
                        but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, e like Aldus PageMaker including versions of Lorem
                        Ipsum.
                    </p>
                    <div class="readmore"><a href="about.php">Read More......</a></div>

                </div>
            </div>
        </div>
    </section>

    <section class="bg-light testimonial">
        <div class="container">
            <div class="d-flex align-items-center">
                <div class="home-contact">
                    <div class="home-contact-text">
                        <h3>Contact Us</h3>
                        <div class="row">
                            <div class="col-md-6">
                                <label>Name</label>
                                <div class="form-group mb-2">
                                    <input type="text" value="" placeholder="John" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label>Email</label>
                                <div class="form-group mb-2">
                                    <input type="text" value="" placeholder="@Gmail.com" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label>Phone No</label>
                                <div class="form-group mb-2">
                                    <input type="text" value="" placeholder="12345678" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label>Location</label>
                                <div class="form-group mb-2">
                                    <input type="text" value="" placeholder="Location" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <label>Message</label>
                                <div class="form-group mb-3">
                                    <textarea class="form-control">Message</textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button class="btn btn-secondary">Send Message</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="testimonial-slider">
                    <h2>What Clients Say About Us</h2>

                    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                        </div>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="star"><i class="las la-star"></i> <i class="las la-star"></i> <i class="las la-star"></i> <i class="las la-star"></i> <i class="las la-star"></i></div>
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also
                                    the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software
                                    like Aldus PageMaker including versions of Lorem Ipsum.</p>
                                <div class="d-flex align-items-center mt-4">
                                    <div class="img"><img src="images/user.png"></div>
                                    <div class="con">
                                        Jason Momoa
                                        <small>Loreum Ipsum</small>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="star"><i class="las la-star"></i> <i class="las la-star"></i> <i class="las la-star"></i> <i class="las la-star"></i> <i class="las la-star"></i></div>
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also
                                    the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software
                                    like Aldus PageMaker including versions of Lorem Ipsum.</p>
                                <div class="d-flex align-items-center  mt-4">
                                    <div class="img"><img src="images/user.png"></div>
                                    <div class="con">
                                        Jason Momoa
                                        <small>Loreum Ipsum</small>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="star"><i class="las la-star"></i> <i class="las la-star"></i> <i class="las la-star"></i> <i class="las la-star"></i> <i class="las la-star"></i></div>
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also
                                    the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software
                                    like Aldus PageMaker including versions of Lorem Ipsum.</p>
                                <div class="d-flex align-items-center  mt-4">
                                    <div class="img"><img src="images/user.png"></div>
                                    <div class="con">
                                        Jason Momoa
                                        <small>Loreum Ipsum</small>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>

                </div>
            </div>


        </div>
        </div>

    </section>
</main>

<?php include("footer.php"); ?>