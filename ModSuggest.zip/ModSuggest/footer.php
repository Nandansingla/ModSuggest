<footer class="text-center">
    <div class="container">
        <div class="row">
            <div class="col-md-12 mb-5"><img src="images/logo-ftr.png" alt="" /></div>
            <div class="col-md-12 mb-5">
                <ul>
                    <li><a href="#">Marketplace</a></li>
                    <li><a href="#">Car Mod Valuation</a></li>
                    <li><a href="privacy-policy.php">Privacy & Policy</a></li>
                    <li><a href="term-condition.php">Term Conditions</a></li>
                </ul>
            </div>
            <div class="col-md-12 mb-5 social">
                <span><a href="#"><i class="fab fa-facebook-f"></i></a></span>
                <span><a href="#"><i class="fab fa-instagram"></i></a></span>
                <span><a href="#"><i class="fab fa-linkedin-in"></i></a></span>
                <span><a href="#"><i class="fab fa-youtube"></i></a></span>
            </div>
            <div class="col-md-12">
                Copyright © 2021 All Rights Reserved.
            </div>

        </div>
    </div>

</footer>

<?php include("modal.php"); ?>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src=" https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
<script src="js/custom.js"></script>

</body>

</html>