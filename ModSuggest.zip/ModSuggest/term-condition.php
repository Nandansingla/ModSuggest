<?php include("header.php"); ?>
<main id="main">
    <section class="inner-banner no-banner">
        <div class="container">
            <div class="border-bottom">
            <h2>Term Condition</h2>
            <div class="breadcrumb">
                <span><a href="index.php">Home</a></span> <span>/</span> </span>Term Conditions</span>
            </div>
            </div>
        </div>
    </section>


    <section class="pb-90">
        <div class="container">
           <h4 class="mb-3"><b>Lorem Ipsum is simply</b></h4>
           <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
           <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
           <ul class="arrow-list">
            <li>Lorem Ipsum has been the industry's standard dummy</li>
            <li>Lorem Ipsum has been the industry's standard dummy</li>
            <li>Lorem Ipsum has been the industry's standard dummy</li>
            <li>Lorem Ipsum has been the industry's standard dummy</li>
            <li>Lorem Ipsum has been the industry's standard dummy</li>
           </ul>
           <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
           <h4 class="mb-3"><b>Lorem Ipsum is simply</b></h4>
           <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
           <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        </div>
    </section>



    </main>

<?php include("footer.php"); ?>
