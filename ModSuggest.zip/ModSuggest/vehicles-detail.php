<?php include("header.php"); ?>

<main id="main">
    <section class="inner-banner">
        <div class="container">
            <h2>Vehicle Detail</h2>
            <div class="breadcrumb">
                <span><a href="index.php">Home</a></span> <span>/</span> <span><a href="#">Our Services</a></span> <span>/</span> <span><a href="#">Find Vehicles</a></span> <span>/</span> </span>Vehicle Detail</span>
            </div>
        </div>
    </section>

    <section class="ptb-90">
        <div class="container">
            <div class="row">
                <div class="col-md-6 detail-img">
                    <div class="swiper mySwiper2 big-img">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                            <img src="images/big1.jpg" alt=""/>
                            </div>
                            <div class="swiper-slide">
                            <img src="images/big2.jpg" alt=""/>
                            </div>
                            <div class="swiper-slide">
                            <img src="images/big3.jpg" alt=""/>
                            </div>
                            <div class="swiper-slide">
                            <img src="images/big1.jpg" alt=""/>
                            </div>
                            <div class="swiper-slide">
                            <img src="images/big2.jpg" alt=""/>
                            </div>
                            <div class="swiper-slide">
                            <img src="images/big3.jpg" alt=""/>
                            </div>
                    
                        </div>
                        <div class="control">
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                        </div>
                    </div>
                    <div thumbsSlider="" class="swiper mySwiper thumb-img">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <img src="images/thumb1.jpg" alt=""/>
                            </div>
                            <div class="swiper-slide">
                            <img src="images/thumb2.jpg" alt=""/>
                            </div>
                            <div class="swiper-slide">
                                <img src="images/thumb3.jpg" alt=""/>
                            </div>
                            <div class="swiper-slide">
                            <img src="images/thumb1.jpg" alt=""/>
                            </div>
                            <div class="swiper-slide">
                            <img src="images/thumb2.jpg" alt=""/>
                            </div>
                            <div class="swiper-slide">
                            <img src="images/thumb3.jpg" alt=""/>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-6 detail-con">
                    
                    <h2 class="mb-4">Audi Q7 Sportline</h2>
                    <div class="rating mb-3">
                        <span><i class="lar la-star"></i></span> 4.5
                    </div>
                    <div class="price mb-3">
                        $100
                    </div>
                    <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p>
                    <div class="d-flex">
                        <button class="btn btn-primary btn-lg me-3">Buy Now</button> <button class="btn btn-outline-secondary btn-lg me-3">Add To Cart</button>
                    </div>
                </div>
            </div>

            <div class="row details-tab mt-5">
                <div class="col-md-12">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Description</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Review (5)</button>
                        </li>

                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                        </div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                        </div>
                    </div>

                </div>
            </div>


        </div>
    </section>




</main>

<?php include("footer.php"); ?>