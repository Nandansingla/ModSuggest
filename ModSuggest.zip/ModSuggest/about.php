<?php include("header.php"); ?>
<main id="main">
    <section class="inner-banner">
        <div class="container">
            <h2>About Us</h2>
            <div class="breadcrumb">
                <span><a href="index.php">Home</a></span> <span>/</span> </span>About Us</span>
            </div>
        </div>
    </section>


    <section class="about ptb-90">
        <div class="container-fluid px-0">
            <div class="row gx-0">
                <div class="col-md-6">
                    <div class="abt-img"><img src="images/about.png" alt="" class="w-100" /></div>
                </div>
                <div class="col-md-6 abt-con d-flex flex-wrap align-self-center">

                    <h2 class="mb-4 pb-2">About Us</h2>
                    <p class="mb-0">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into
                        electronic typesetting, remaining essentially unchanged. It popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishin software like Aldus PageMaker including
                        versions of Lorem Ipsum.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer too galley of type and scrambled it to make a t specimen book. It has survived not only five centuries,
                        but also leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s wit release of Letraset sheets containing Lorem Ipsum passages, e like Aldus PageMaker including versions Lorem Ipsum.Lorem
                        Ipsum has been the industry's standard dummy text ever since the 1500s, when unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic
                        typesetting, remaining essentially unchanged. It popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recent with desktop publishin software like Aldus PageMaker including versions
                        of Lorem Ipsum.Lorem Ipsum been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a t specimen book. It has survived not only five centuries, but also
                        the lea into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, e like Aldus PageMaker including versions of Lorem Ipsum.
                    </p>                   

                </div>
            </div>
        </div>
    </section>

    <section class="ptb-115 chooseus">
        <div class="container position-relative">
            <h2 class="mb-4 pb-2">Why Choose us</h2>
            <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic
                typesetting, remaining essentially unchanged.</p>

            <div class="row mt-5">
                <div class="col-md-4">
                    <div class="box digit-txt one h-100">
                        <a href="#">
                            <div class="img mb-3"><img src="images/choose1.png" alt=""/></div>
                            <h3><b>Expert Workers</b></h3>
                            <p>Lorem Ipsum has been the industry's st dummy text ever since the 1500s, when an unkno printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum has been the industry's standard dummy.</p>
                        </a>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="box digit-txt two h-100">
                        <a href="#">
                            <div class="img mb-3"><img src="images/choose2.png" alt=""/></div>
                            <h3><b>Quick & Efficient</b></h3>
                            <p>Lorem Ipsum has been the industry's st dummy text ever since the 1500s, when an unkno printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum has been the industry's standard dummy.</p>
                        </a>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="box digit-txt three h-100">
                        <a href="#">
                            <div class="img mb-3"><img src="images/choose3.png" alt=""/></div>
                            <h3><b>Support 24/7</b></h3>
                            <p>Lorem Ipsum has been the industry's st dummy text ever since the 1500s, when an unkno printer took a galley of type and scrambled it to make a type specimen book. Lorem Ipsum has been the industry's standard dummy.</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="ptb-90 team">
        <div class="container">
            <h2 class="mb-5 text-center">Our Team</h2>
            <div class="row">
                <div class="col-md-3 text-center">
                    <div class="img"><img src="images/team1.jpg" alt=""/></div>
                    <h4>Peter Oldy</h4>
                    <small>Founder of Company</small>
                </div>
                <div class="col-md-3 text-center">
                    <div class="img"><img src="images/team2.jpg" alt=""/></div>
                    <h4>Richard Wagner</h4>
                    <small>Main Mechanic</small>
                </div>
                <div class="col-md-3 text-center">
                    <div class="img"><img src="images/team3.jpg" alt=""/></div>
                    <h4>James Willey</h4>
                    <small>Echnician</small>
                </div>
                <div class="col-md-3 text-center">
                    <div class="img"><img src="images/team4.jpg" alt=""/></div>
                    <h4>William Berry</h4>
                    <small>Service Advisor</small>
                </div>
            </div>
        </div>
    </section>


    </main>

<?php include("footer.php"); ?>
