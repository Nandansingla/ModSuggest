<?php include("header.php"); ?>

<main id="main">
    <section class="inner-banner">
        <div class="container">
            <h2>Find Shop</h2>
            <div class="breadcrumb">
                <span><a href="#">Home</a></span>
                <span>/</span>
                <span><a href="#">Our Services</a></span>
                <span>/</span>
                <span>Find Shop</span>
            </div>
        </div>
    </section>

    <section class="ptb-90 find-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <aside class="vehicle-sidebar">
                        <div class="search-box bxs br-10">
                            <h4>Find Your Shop</h4>
                            <form action="/">
                                <input type="text" placeholder="Search">
                                <button type="submit" class="btn btn-primary">
                                    <i class="las la-search"></i>
                                </button>
                            </form>
                        </div>
                        <h4>Products</h4>
                        <div class="single bxs br-10">
                            <h4>Star Rating</h4>
                            <ul>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>
                                            <i class="las la-star"></i>
                                            <i class="las la-star"></i>
                                            <i class="las la-star"></i>
                                            <i class="las la-star"></i>
                                            <i class="las la-star"></i>
                                            <small>(800)</small>
                                        </span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>
                                            <i class="las la-star"></i>
                                            <i class="las la-star"></i>
                                            <i class="las la-star"></i>
                                            <i class="las la-star"></i>
                                            <i class="lar la-star"></i>
                                            <small>(750)</small>
                                        </span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>
                                            <i class="las la-star"></i>
                                            <i class="las la-star"></i>
                                            <i class="las la-star"></i>
                                            <i class="lar la-star"></i>
                                            <i class="lar la-star"></i>
                                            <small>(700)</small>
                                        </span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>
                                            <i class="las la-star"></i>
                                            <i class="las la-star"></i>
                                            <i class="lar la-star"></i>
                                            <i class="lar la-star"></i>
                                            <i class="lar la-star"></i>
                                            <small>(650)</small>
                                        </span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>
                                            <i class="las la-star"></i>
                                            <i class="lar la-star"></i>
                                            <i class="lar la-star"></i>
                                            <i class="lar la-star"></i>
                                            <i class="lar la-star"></i>
                                            <small>(550)</small>
                                        </span>
                                    </label>
                                </li>
                            </ul>
                        </div>
                        <div class="single bxs br-10">
                            <h4>Categories</h4>
                            <ul>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>Lorem Ipsum <small>(2000)</small></span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>Lorem Ipsum <small>(2010)</small></span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>Lorem Ipsum <small>(3000)</small></span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>Lorem Ipsum <small>(3500)</small></span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>Lorem Ipsum <small>(4000)</small></span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>Lorem Ipsum <small>(4500)</small></span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>Lorem Ipsum <small>(5000)</small></span>
                                    </label>
                                </li>
                            </ul>
                        </div>
                        <div class="single bxs br-10">
                            <h4>Select Your Price</h4>
                            <ul>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>0$-500$</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>500$-1000$</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>1000$-5000$</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>5000$-10000$</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>10000$+</span>
                                    </label>
                                </li>
                            </ul>
                        </div>
                    </aside>
                </div>
                <div class="col-md-9 ps-5">
                    <div class="filter-box br-10">
                        <p>Showing 1-7 of 80 Result</p>
                        <a href="#">
                            <figure><img src="images/filter.png"></figure>
                            Filter
                        </a>
                    </div>
                    <div class="pShopSingle">
                        <div class="row align-items-center">
                            <div class="col-md-5 align-content-start">
                                <figure><img src="images/shop-img1.jpg"></figure>
                            </div>
                            <div class="col-md-7 ps-5">
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</p>
                            </div>
                        </div>
                    </div>
                    <h2 class="my-5">Find Your Shop</h2>
                    <div class="pShopSingle">
                        <div class="row align-items-center">
                            <div class="col-md-5 align-content-start">
                                <figure><img src="images/shop-img2.jpg"></figure>
                            </div>
                            <div class="col-md-7 ps-5">
                                <div class="star-rating mb-4">
                                    <i class="las la-star"></i>
                                    <i class="las la-star"></i>
                                    <i class="las la-star"></i>
                                    <i class="las la-star"></i>
                                    <i class="las la-star"></i>
                                </div>
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently.</p>
                                <div class="d-flex align-items-center mt-4">
                                    <label><input type="checkbox"> Compare</label>
                                    <a href="#" class="btn btn-lg btn-primary ms-5">Get Quote</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="pShopSingle">
                        <div class="row align-items-center">
                            <div class="col-md-5 align-content-start">
                                <figure><img src="images/shop-img3.jpg"></figure>
                            </div>
                            <div class="col-md-7 ps-5">
                                <div class="star-rating mb-4">
                                    <i class="las la-star"></i>
                                    <i class="las la-star"></i>
                                    <i class="las la-star"></i>
                                    <i class="las la-star"></i>
                                    <i class="las la-star"></i>
                                </div>
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently.</p>
                                <div class="d-flex align-items-center mt-4">
                                    <label><input type="checkbox"> Compare</label>
                                    <a href="#" class="btn btn-lg btn-primary ms-5">Get Quote</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="pShopSingle">
                        <div class="row align-items-center">
                            <div class="col-md-5 align-content-start">
                                <figure><img src="images/shop-img4.jpg"></figure>
                            </div>
                            <div class="col-md-7 ps-5">
                                <div class="star-rating mb-4">
                                    <i class="las la-star"></i>
                                    <i class="las la-star"></i>
                                    <i class="las la-star"></i>
                                    <i class="las la-star"></i>
                                    <i class="las la-star"></i>
                                </div>
                                <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently.</p>
                                <div class="d-flex align-items-center mt-4">
                                    <label><input type="checkbox"> Compare</label>
                                    <a href="#" class="btn btn-lg btn-primary ms-5">Get Quote</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include("footer.php"); ?>