<?php include("header.php"); ?>

<main id="main">
    <section class="inner-banner">
        <div class="container">
            <h2>Find Part</h2>
            <div class="breadcrumb">
                <span><a href="#">Home</a></span>
                <span>/</span>
                <span><a href="#">Our Services</a></span>
                <span>/</span>
                <span>Find Part</span>
            </div>
        </div>
    </section>

    <section class="ptb-90 find-section">
        <div class="container">
            <div class="row gx-5">
                <div class="col-md-3">
                    <aside class="vehicle-sidebar">
                        <figure class="ad">
                            <img src="images/ad1.jpg">
                        </figure>
                    </aside>
                </div>
                <div class="col-md-9">
                    <div class="searchbox br-10">
                        <input type="text" placeholder="Enter Vehicle Year, Make, And Model">
                        <span><i class="las la-search"></i> Search</span>
                    </div>
                    <h2 class="mt-5">Find Your Shop</h2>
                    <div class="row gx-5 row-cols-md-3">
                        <div class="col">
                            <div class="listSingle">
                                <figure><img src="images/shopimage1.jpg"></figure>
                                <h3>Lorem Ipsum</h3>
                                <p>$5,000</p>
                            </div>
                        </div>
                        <div class="col">
                            <div class="listSingle">
                                <figure><img src="images/shopimage2.jpg"></figure>
                                <h3>Lorem Ipsum</h3>
                                <p>$5,000</p>
                            </div>
                        </div>
                        <div class="col">
                            <div class="listSingle">
                                <figure><img src="images/shopimage3.jpg"></figure>
                                <h3>Lorem Ipsum</h3>
                                <p>$5,000</p>
                            </div>
                        </div>
                        <div class="col">
                            <div class="listSingle">
                                <figure><img src="images/shopimage4.jpg"></figure>
                                <h3>Lorem Ipsum</h3>
                                <p>$5,000</p>
                            </div>
                        </div>
                        <div class="col">
                            <div class="listSingle">
                                <figure><img src="images/shopimage5.jpg"></figure>
                                <h3>Lorem Ipsum</h3>
                                <p>$5,000</p>
                            </div>
                        </div>
                        <div class="col">
                            <div class="listSingle">
                                <figure><img src="images/shopimage6.jpg"></figure>
                                <h3>Lorem Ipsum</h3>
                                <p>$5,000</p>
                            </div>
                        </div>
                        <div class="col">
                            <div class="listSingle">
                                <figure><img src="images/shopimage7.jpg"></figure>
                                <h3>Lorem Ipsum</h3>
                                <p>$5,000</p>
                            </div>
                        </div>
                        <div class="col">
                            <div class="listSingle">
                                <figure><img src="images/shopimage9.jpg"></figure>
                                <h3>Lorem Ipsum</h3>
                                <p>$5,000</p>
                            </div>
                        </div>
                        <div class="col">
                            <div class="listSingle">
                                <figure><img src="images/shopimage8.jpg"></figure>
                                <h3>Lorem Ipsum</h3>
                                <p>$5,000</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include("footer.php"); ?>