<?php include("header.php"); ?>

<main id="main">
    <section class="inner-banner">
        <div class="container">
            <h2>Find Vehicle</h2>
            <div class="breadcrumb">
                <span><a href="#">Home</a></span>
                <span>/</span>
                <span><a href="#">Our Services</a></span>
                <span>/</span>
                <span>Find Vehicle</span>
            </div>
        </div>
    </section>

    <section class="ptb-90 find-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <aside class="vehicle-sidebar">
                        <div class="search-box bxs br-10">
                            <h4>Find Your Vehicle</h4>
                            <form action="/">
                                <input type="text" placeholder="Search">
                                <button type="submit" class="btn btn-primary">
                                    <i class="las la-search"></i>
                                </button>
                            </form>
                        </div>
                        <div class="single bxs br-10">
                            <h4>Select Car's Brand</h4>
                            <ul>
                                <li>
                                    <a href="#">
                                        <strong>
                                            <figure><img src="images/icon1-1.png"></figure>
                                            Honda
                                        </strong>
                                        <span>(15)</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <strong>
                                            <figure><img src="images/icon7.png"></figure>
                                            Audi
                                        </strong>
                                        <span>(20)</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <strong>
                                            <figure><img src="images/icon1-2.png"></figure>
                                            Nissan
                                        </strong>
                                        <span>(10)</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <strong>
                                            <figure><img src="images/icon5.png"></figure>
                                            Mazda
                                        </strong>
                                        <span>(15)</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <strong>
                                            <figure><img src="images/icon6.png"></figure>
                                            Toyota
                                        </strong>
                                        <span>(15)</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <strong>
                                            <figure><img src="images/icon1-3.png"></figure>
                                            BMW
                                        </strong>
                                        <span>(15)</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <strong>
                                            <figure><img src="images/icon1-4.png"></figure>
                                            Honda
                                        </strong>
                                        <span>(15)</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="single bxs br-10">
                            <h4>Select Car's Seating</h4>
                            <ul>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>2 Seater Car</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>4 Seater Car</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>5 Seater Car</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>6 Seater Car</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>8 Seater Car</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>10 Seater Car</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>12 Seater Car</span>
                                    </label>
                                </li>
                            </ul>
                        </div>
                        <div class="single bxs br-10">
                            <h4>Select Car's Seating</h4>
                            <ul>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>2 Seater Car</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>4 Seater Car</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>5 Seater Car</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>6 Seater Car</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>8 Seater Car</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>10 Seater Car</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>12 Seater Car</span>
                                    </label>
                                </li>
                            </ul>
                        </div>
                        <div class="single bxs br-10">
                            <h4>Select Your Price</h4>
                            <ul>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>0$-500$</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>500$-1000$</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>1000$-5000$</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>5000$-10000$</span>
                                    </label>
                                </li>
                                <li>
                                    <label>
                                        <input type="checkbox">
                                        <span>10000$+</span>
                                    </label>
                                </li>
                            </ul>
                        </div>
                    </aside>
                </div>
                <div class="col-md-9 ps-5">
                    <div class="filter-box br-10">
                        <p>Showing 1-7 of 80 Result</p>
                        <a href="#">
                            <figure><img src="images/filter.png"></figure>
                            Filter
                        </a>
                    </div>
                    <div class="pSingle bxs br-10">
                        <div class="row gx-5">
                            <div class="col-md-4 col-xxl-4">
                                <figure class="pImg"><img src="images/product-single-img1.jpg"></figure>
                                <ul class="pList">
                                    <li>
                                        <figure><img src="images/petrol-icon.png"></figure>
                                        Petrol
                                    </li>
                                    <li>
                                        <figure><img src="images/speed-icon.png"></figure>
                                        20.000Km
                                    </li>
                                    <li>
                                        <figure><img src="images/car-icon.png"></figure>
                                        Auto
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-4 col-xxl-5">
                                <div class="pContent">
                                    <h6>Suv</h6>
                                    <h4>Audi Q7 Sportline</h4>
                                    <p>7 Seater Car</p>
                                </div>
                            </div>
                            <div class="col-md-4 col-xxl-3">
                                <ul class="pCList">
                                    <li>Best Auto Warranties</li>
                                    <li>Flexible Payment Palns</li>
                                    <li>Competitive Pricing</li>
                                    <li>24*7 Support</li>
                                </ul>
                                <div class="priceBox br-10">
                                    <p>Selling Price</p>
                                    <h3>$45.000</h3>
                                    <a href="#" class="btn btn-white">Book Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="pSingle bxs br-10">
                        <div class="row gx-5">
                         <div class="col-md-4 col-xxl-4">
                                <figure class="pImg"><img src="images/product-single-img1.jpg"></figure>
                                <ul class="pList">
                                    <li>
                                        <figure><img src="images/petrol-icon.png"></figure>
                                        Petrol
                                    </li>
                                    <li>
                                        <figure><img src="images/speed-icon.png"></figure>
                                        20.000Km
                                    </li>
                                    <li>
                                        <figure><img src="images/car-icon.png"></figure>
                                        Auto
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-4 col-xxl-5">
                                <div class="pContent">
                                    <h6>Suv</h6>
                                    <h4>Audi Q7 Sportline</h4>
                                    <p>7 Seater Car</p>
                                </div>
                            </div>
                            <div class="col-md-4 col-xxl-3">
                                <ul class="pCList">
                                    <li>Best Auto Warranties</li>
                                    <li>Flexible Payment Palns</li>
                                    <li>Competitive Pricing</li>
                                    <li>24*7 Support</li>
                                </ul>
                                <div class="priceBox br-10">
                                    <p>Selling Price</p>
                                    <h3>$45.000</h3>
                                    <a href="#" class="btn btn-white">Book Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="pSingle bxs br-10">
                        <div class="row gx-5">
                        <div class="col-md-4 col-xxl-4">
                                <figure class="pImg"><img src="images/product-single-img1.jpg"></figure>
                                <ul class="pList">
                                    <li>
                                        <figure><img src="images/petrol-icon.png"></figure>
                                        Petrol
                                    </li>
                                    <li>
                                        <figure><img src="images/speed-icon.png"></figure>
                                        20.000Km
                                    </li>
                                    <li>
                                        <figure><img src="images/car-icon.png"></figure>
                                        Auto
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-4 col-xxl-5">
                                <div class="pContent">
                                    <h6>Suv</h6>
                                    <h4>Audi Q7 Sportline</h4>
                                    <p>7 Seater Car</p>
                                </div>
                            </div>
                            <div class="col-md-4 col-xxl-3">
                                <ul class="pCList">
                                    <li>Best Auto Warranties</li>
                                    <li>Flexible Payment Palns</li>
                                    <li>Competitive Pricing</li>
                                    <li>24*7 Support</li>
                                </ul>
                                <div class="priceBox br-10">
                                    <p>Selling Price</p>
                                    <h3>$45.000</h3>
                                    <a href="#" class="btn btn-white">Book Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="pSingle bxs br-10">
                        <div class="row gx-5">
                        <div class="col-md-4 col-xxl-4">
                                <figure class="pImg"><img src="images/product-single-img1.jpg"></figure>
                                <ul class="pList">
                                    <li>
                                        <figure><img src="images/petrol-icon.png"></figure>
                                        Petrol
                                    </li>
                                    <li>
                                        <figure><img src="images/speed-icon.png"></figure>
                                        20.000Km
                                    </li>
                                    <li>
                                        <figure><img src="images/car-icon.png"></figure>
                                        Auto
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-4 col-xxl-5">
                                <div class="pContent">
                                    <h6>Suv</h6>
                                    <h4>Audi Q7 Sportline</h4>
                                    <p>7 Seater Car</p>
                                </div>
                            </div>
                            <div class="col-md-4 col-xxl-3">
                                <ul class="pCList">
                                    <li>Best Auto Warranties</li>
                                    <li>Flexible Payment Palns</li>
                                    <li>Competitive Pricing</li>
                                    <li>24*7 Support</li>
                                </ul>
                                <div class="priceBox br-10">
                                    <p>Selling Price</p>
                                    <h3>$45.000</h3>
                                    <a href="#" class="btn btn-white">Book Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination">
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Previous">
                                    <i class="las la-angle-left"></i>
                                </a>
                            </li>
                            <li class="page-item"><a class="page-link active" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item"><a class="page-link" href="#">4</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                    <i class="las la-angle-right"></i>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include("footer.php"); ?>